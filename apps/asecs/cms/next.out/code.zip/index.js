"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// lib/server-handler/index.ts
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);
var import_node_fs = require("fs");
var import_node_path = __toESM(require("path"));
var import_serverless_http = __toESM(require("serverless-http"));
process.chdir(__dirname);
process.env.NODE_ENV = "production";
var { default: NextServer } = require("next/dist/server/next-server");
var configFilePath = process.env.NEXT_CONFIG_FILE ?? "./config.json";
var nextConf = JSON.parse((0, import_node_fs.readFileSync)(configFilePath, "utf-8"));
var config = {
  hostname: "localhost",
  port: Number(process.env.PORT) || 3e3,
  dir: import_node_path.default.join(__dirname),
  dev: false,
  customServer: false,
  conf: nextConf
};
var getErrMessage = (e) => ({ message: "Server failed to respond.", details: e });
var nextHandler = new NextServer(config).getRequestHandler();
var server = (0, import_serverless_http.default)(
  async (req, res) => {
    try {
      await nextHandler(req, res);
    } catch (e) {
      console.error(`NextJS request failed due to:`);
      console.error(e);
      res.setHeader("Content-Type", "application/json");
      res.end(JSON.stringify(getErrMessage(e), null, 3));
    }
  },
  {
    // We have separate function for handling images. Assets are handled by S3.
    binary: true,
    provider: "aws",
    basePath: process.env.NEXTJS_LAMBDA_BASE_PATH,
    request: (request) => {
      delete request.body;
    }
  }
);
var handler = server;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
